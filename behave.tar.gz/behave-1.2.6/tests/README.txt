This is the new directory root for:

* unit tests
* functional tests (that do not use feature files)

The tests here use the :pypi:`pytest` test framework for testing.

.. note::

    Other tests in the collocated "../test/" directory will be eventually
    cleaned and converted in (clean) pytests ;-)

