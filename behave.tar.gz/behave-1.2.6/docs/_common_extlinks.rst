
.. _behave:     https://github.com/behave/behave
.. _behave4cmd: https://github.com/behave/behave4cmd

.. _`pytest.fixture`:   https://docs.pytest.org/en/latest/fixture.html
.. _`@pytest.fixture`:  https://docs.pytest.org/en/latest/fixture.html
.. _`scope guard`:      https://en.wikibooks.org/wiki/More_C++_Idioms/Scope_Guard
.. _`C++ scope guard`:  https://en.wikibooks.org/wiki/More_C++_Idioms/Scope_Guard

.. _Cucumber:   https://cucumber.io/
.. _Lettuce:    http://lettuce.it/

.. _Selenium:   http://docs.seleniumhq.org/

.. _PyCharm:        https://www.jetbrains.com/pycharm/
.. _Eclipse:        http://www.eclipse.org/
.. _VisualStudio:   https://www.visualstudio.com/

.. _`PyCharm BDD`: https://blog.jetbrains.com/pycharm/2014/09/feature-spotlight-behavior-driven-development-in-pycharm/
.. _`Cucumber-Eclipse`: http://cucumber.github.io/cucumber-eclipse/

.. _ctags:      http://ctags.sourceforge.net/
