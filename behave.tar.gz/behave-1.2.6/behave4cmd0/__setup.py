# -*- coding: utf-8 -*-

from __future__ import absolute_import
import os.path

# -----------------------------------------------------------------------------
# CONSTANTS:
# -----------------------------------------------------------------------------
HERE    = os.path.dirname(__file__)
TOP     = os.path.join(HERE, "..")
TOPA    = os.path.abspath(TOP)
